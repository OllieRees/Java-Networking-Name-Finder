This is the initial release of my Space Cadets 1 project. 
It's fully tested and working. 
It only works on email IDs for staff in the ecs department of Southampton uni.
Using JRE 1.8
